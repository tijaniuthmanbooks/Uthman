/* Build script: generates every page of the site from home.template.html + data.json.
   Usage:  CONTACT_EMAIL=you@example.com SITE_URL=https://your-domain.com node build.js */
const fs = require('fs');
const path = require('path');

const SITE = (process.argv[2] || process.env.SITE_URL || (process.env.VERCEL_PROJECT_PRODUCTION_URL ? 'https://' + process.env.VERCEL_PROJECT_PRODUCTION_URL : '') || 'https://YOUR-DOMAIN.com').replace(/\/+$/, '');
const EMAIL = process.env.CONTACT_EMAIL || 'YOUR-EMAIL@example.com';
const OUT = path.resolve(__dirname, 'dist');
fs.rmSync(OUT, { recursive: true, force: true });
fs.cpSync(path.join(__dirname, 'assets'), path.join(OUT, 'assets'), { recursive: true });
if (!process.env.CONTACT_EMAIL) console.warn('WARNING: CONTACT_EMAIL is not set, so the contact email shows a placeholder.');
const { CASES, DEMOS } = JSON.parse(fs.readFileSync(path.join(__dirname, 'data.json'), 'utf8'));
const TODAY = '2026-11-15';

const WA = 'https://wa.me/2348136720953';
const SOCIAL = {
  LinkedIn: 'https://www.linkedin.com/in/tijani-uthman/',
  Upwork: 'https://www.upwork.com/freelancers/~017abd9644334bde1f?mp_source=share',
  Instagram: 'https://www.instagram.com/tijaniuthmanopeyemi32/',
  Facebook: 'https://www.facebook.com/profile.php?id=100084764225267',
  TikTok: 'https://www.tiktok.com/@uthmantijani32',
  Threads: 'https://www.threads.com/@tijaniuthmanopeyemi32'
};
const esc = (s) => String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');

const SLUG = { eno: 'book-of-eno', kiko: 'el-cocodrilo-kiko', ext: 'extinction-or-evolution', fmd: 'finding-my-direction', skill: 'power-of-learning-a-skill', stop: 'decision-to-stop-depending-on-others' };
const ORDER = ['eno', 'kiko', 'ext', 'fmd', 'skill', 'stop'];
const CASE_SEO = {
  eno: { title: 'The Book of Eno: editing and Kindle cover case study', desc: 'Case study: developmental editing, Kindle cover design and interior formatting for The Book of Eno, a Christian novel now live on Amazon Kindle.', services: ['developmental-editing', 'book-cover-and-interior-design'] },
  kiko: { title: 'El Cocodrilo Kiko: bilingual picture book layout case study', desc: 'Case study: Spanish and English interior layout and full-wrap cover prep for an 80-page Amazon KDP hardcover picture book.', services: ['book-cover-and-interior-design'] },
  ext: { title: 'Extinction or Evolution?: beta reading case study', desc: 'Case study: an 8-page beta reading and developmental critique of a nonfiction book about AI and humanity.', services: ['manuscript-assessment-and-beta-reading'] },
  fmd: { title: 'Finding My Direction: interior formatting before and after', desc: 'Before and after: interior formatting and proofreading of Finding My Direction, from a plain Word file to a designed book interior.', services: ['proofreading', 'book-cover-and-interior-design'] },
  skill: { title: 'The Power of Learning a Skill: sample edit and cover', desc: 'Sample project: four editing passes and a full-wrap cover for a ten-chapter personal-growth manuscript, with annotated tracked-change examples.', services: ['developmental-editing', 'line-and-copy-editing', 'proofreading', 'book-cover-and-interior-design'] },
  stop: { title: 'Stop Depending on Others: sample memoir edit and cover', desc: 'Sample project: four editing passes and a full-wrap cover for a ten-chapter memoir, with annotated tracked-change examples.', services: ['developmental-editing', 'line-and-copy-editing', 'proofreading', 'book-cover-and-interior-design'] }
};
const PDF_FILES = { eno: 'book-of-eno-case-study.pdf', kiko: 'el-cocodrilo-kiko-case-study.pdf', ext: 'extinction-or-evolution-beta-reading.pdf', fmd: 'finding-my-direction-before-after.pdf', skill: 'power-of-learning-a-skill-case-study.pdf', stop: 'stop-depending-on-others-case-study.pdf' };

const EDWARD = ['“I highly recommend Tijani Uthman as a book editor and manuscript consultant. … He delivered exceptionally detailed, thoughtful, and constructive feedback that went far beyond what I expected. … Working with him felt collaborative and supportive, exactly what a writer needs when polishing a story with a meaningful message.”', 'Edward L. Betz Jr., author of The Book of Eno'];
const SHALOM = ['“Tijani delivered professional work that went beyond my expectations. He was thorough, attentive to detail, and did an excellent job while preserving the original voice and meaning of my manuscript.”', 'shalom_format, client in the United States (Fiverr)'];
const ANUSH = ['“Tijani gave clear, honest feedback and really cared about the story. … If you’re looking for a reader who is thoughtful, reliable, and truly wants your book to succeed, I highly recommend Tijani.”', 'Anush Rashid, LinkedIn recommendation'];
const INAYAT = ['“Thank you so much for taking the time to read my chapter and sharing such thoughtful feedback, Tijani. You hit the nail on the head! … Your suggestions are incredibly helpful.”', 'Inayat Noor, fiction author'];

const SERVICES = {
  'developmental-editing': {
    nav: 'Developmental editing', serviceName: 'Developmental editing',
    title: 'Developmental editing for self-publishing authors',
    desc: 'Developmental editing for fiction and nonfiction: structure, pacing, repetition and argument, with chapter-by-chapter notes. Free 500-word sample edit. Serving authors in the US and Nigeria.',
    h1: 'Developmental editing for self-publishing authors',
    lead: 'A big-picture edit that fixes what is holding your manuscript back before anyone polishes a sentence. You get an editorial letter with chapter-by-chapter notes and a clear order for your revisions.',
    sections: [
      { h: 'What developmental editing looks at', p: ['I read your manuscript as a reader first, then as an editor. Where attention drops, where an idea repeats and where a promise is not kept are the places I mark.'], list: ['Structure: the order of chapters and sections, and what each one is for', 'Pacing: slow openings, uneven middles and reveals that arrive too early', 'Argument and evidence in nonfiction, and character and plot clarity in fiction', 'Repetition: ideas, phrases and points told more than once', 'Gaps: where readers need a scene, a source or an example'] },
      { h: 'What you get', list: ['An editorial letter with chapter-by-chapter notes', 'A clear order for your revisions, big issues first', 'A list of lines and passages to keep exactly as written', 'Honest, specific feedback, with questions flagged where I need your input'], p: ['For longer projects I can guide your revisions across several rounds. On The Book of Eno that meant a 24-page review, a Chapter 1 report and then an editorial review of the next draft.'] },
      { h: 'Who it suits', p: ['New drafts, and manuscripts that feel almost there but not quite. I work with first-time self-publishers, fiction writers, nonfiction and business authors, and academics in the United States and Nigeria.'] },
      { h: 'An example from my sample projects', p: ['In a sample memoir, Chapter 1 previewed the whole book: its 14 pages introduced ideas that became Chapters 2, 3 and 4. I mapped each Chapter 1 section to the chapter that develops it and recommended what to keep, move or shrink, so the later chapters read as a payoff instead of a repeat.', 'In another sample, one idea, “confidence comes after action”, appeared in three chapters in nearly the same words. I gave each chapter a different job for it: plant it, show the fear of starting, and prove it with one real moment from the author’s own learning.'] }
    ],
    quotes: [EDWARD], projects: ['eno', 'ext', 'stop'],
    faqs: [
      ['When should I choose developmental editing?', 'Choose it when your draft is new, or when something feels off but you cannot say what: pacing, repetition or structure. Fixing these first means you do not pay to polish sentences that later get cut.'],
      ['Will you rewrite my book?', 'No. I tighten and clarify; I don’t rewrite you. You make the revisions, and I tell you which lines carry your voice and should stay.'],
      ['How do I start?', 'Send your first 500 words for a free sample edit. After that I recommend the right level of editing and quote based on your word count, genre, formats and launch date.']
    ]
  },
  'line-and-copy-editing': {
    nav: 'Line and copy editing', serviceName: 'Line editing and copyediting',
    title: 'Line editing and copyediting for self-publishing authors',
    desc: 'Line editing and copyediting that tighten your sentences and fix grammar and consistency, with a reason beside every change. Free 500-word sample edit. Serving authors in the US and Nigeria.',
    h1: 'Line editing and copyediting for self-publishing authors',
    lead: 'Sentence-by-sentence editing that makes your writing clearer and more confident while keeping your voice. Every change comes with a reason, so your next chapter starts cleaner.',
    sections: [
      { h: 'Line editing: clarity, rhythm and tightening', p: ['A line edit works on how each sentence reads: repeated words, slow constructions and hedges that soften claims you clearly believe. I tighten and clarify, and I leave the lines that carry your personality exactly as written.'] },
      { h: 'Copyediting: grammar and consistency', list: ['Grammar, spelling and punctuation', 'Consistent style, including capitalisation and heading patterns', 'Hedging words that weaken a claim', 'Questions flagged for you where I would otherwise have to guess'] },
      { h: 'What you get', list: ['Tracked changes with a short reason beside each one', 'A clean manuscript with consistent style', 'The habits I found in your prose, flagged so you can spot them yourself next time'] },
      { h: 'See a line edit', p: ['This example comes from a sample manuscript. Every idea was kept; the passage just reads cleaner.'], demo: 0 }
    ],
    quotes: [SHALOM], projects: ['skill', 'stop'],
    faqs: [
      ['What is the difference between line editing and copyediting?', 'A line edit improves how sentences read: clarity, rhythm and tightening. A copyedit corrects and standardises: grammar, spelling, punctuation and consistency. I often do both together once the structure is settled.'],
      ['Will my voice change?', 'No. I tighten and clarify; I don’t rewrite you. Lines that carry your personality are left exactly as written.'],
      ['Can I see each change?', 'Yes. Edits come as tracked changes, each with a short reason, so you decide what to keep.']
    ]
  },
  'proofreading': {
    nav: 'Proofreading', serviceName: 'Proofreading',
    title: 'Proofreading for self-publishing authors',
    desc: 'Proofreading before you print or upload to Amazon KDP: typos, front-matter slips and unfinished sentences, with open questions flagged. Free 500-word sample edit. Serving authors in the US and Nigeria.',
    h1: 'Proofreading for self-publishing authors',
    lead: 'The last look before you print or upload. I catch typos, front-matter slips and unfinished sentences, and I flag anything I cannot settle without you.',
    sections: [
      { h: 'What proofreading catches', list: ['Typos and missing punctuation', 'A contents page that does not match your chapters', 'Copyright page problems, including an unnamed copyright holder', 'Unfinished sentences, especially at the end of an introduction', 'Front-matter slips, because the first pages decide how carefully readers expect the rest to be made'] },
      { h: 'What you get', list: ['A publication-ready file', 'A short list of open questions that need your decision before printing'] },
      { h: 'Proofread first or edit first?', p: ['Proofreading comes last. If your structure or sentences still need work, start with developmental editing or a line edit, so you do not proofread text that will change.'] },
      { h: 'See a proofreading example', p: ['This example shows small slips in the front matter of a sample manuscript, and a question I could not answer for the author.'], demo: 2 }
    ],
    quotes: [SHALOM], projects: ['fmd', 'skill', 'stop'],
    faqs: [
      ['Is proofreading the same as editing?', 'No. Editing improves structure, sentences and style. Proofreading is the final check for errors after the editing is done.'],
      ['Can you proofread and format my interior?', 'Yes. For Finding My Direction I did both interior formatting and proofreading, so the book went from a plain Word file to a designed interior in one process.']
    ]
  },
  'manuscript-assessment-and-beta-reading': {
    nav: 'Manuscript assessment', serviceName: 'Manuscript assessment and beta reading',
    title: 'Manuscript assessment and beta reading',
    desc: 'An honest manuscript assessment or beta read for fiction and nonfiction: strengths, risks and a ranked revision plan. Free 500-word sample edit. Serving authors in the US and Nigeria.',
    h1: 'Manuscript assessment and beta reading',
    lead: 'An honest read of your manuscript, or part of it, from a reader’s and an editor’s point of view. You get a written report with strengths, risks, line-level suggestions and a ranked revision plan.',
    sections: [
      { h: 'How I read', p: ['I read as a reader first, then as an editor. For fiction I look at plot, characters, pacing and dialogue. For nonfiction I swap that checklist for argument, voice and evidence, so the feedback fits the book and not a template.'] },
      { h: 'What the report contains', list: ['A scope note: what I covered and what I did not', 'Strengths and risks, section by section', 'Notes on voice, internal logic and writing craft', 'Line-level rewrite suggestions', 'A revision plan ranked by priority, for example 4 high, 3 medium and 2 low items', 'An open offer to talk through any of the feedback'] },
      { h: 'You can start small', p: ['An assessment does not need a finished book. For one nonfiction title I read the Introduction and the opening of Chapter 1 (pages 7 to 27). I say clearly what is outside the scope instead of guessing.'] },
      { h: 'An example from my work', p: ['For a nonfiction book about AI and humanity, an 8-page report covered the Introduction and the start of Chapter 1. It named the strongest section, flagged an unsourced statistic and a date that needed updating for a 2026 book, and ended with a ranked plan.'] }
    ],
    quotes: [ANUSH, INAYAT], projects: ['ext', 'eno'],
    faqs: [
      ['What is the difference between a beta read and a developmental edit?', 'A beta read tells you how the book works for a reader: what lands, what drags and what to fix first. A developmental edit goes deeper, with chapter-by-chapter notes and guidance on structure. Many authors start with an assessment, then decide.'],
      ['Do I need a finished manuscript?', 'No. I can read an introduction, a few chapters or the whole book. The report states exactly what was covered.']
    ]
  },
  'book-cover-and-interior-design': {
    nav: 'Cover and interior design', serviceName: 'Book cover design and interior formatting',
    title: 'Book cover design and interior formatting for Amazon KDP',
    desc: 'Book cover design and interior formatting for Kindle, paperback and hardcover on Amazon KDP, from the same editor who polishes your text. Serving authors in the US and Nigeria.',
    h1: 'Book cover design and interior formatting for Amazon KDP',
    lead: 'Editing is my main work, but a well-edited book still needs a cover and pages that look professional. I design both, so the promise on the cover matches what is inside.',
    sections: [
      { h: 'Cover design', list: ['Front, spine and back designed as one wrap', 'Print specs set for your trim size, bleed and spine width', 'Space left for the barcode', 'Titles and author names that stay readable at thumbnail size', 'Mockups you can use for launch posts and sales pages'] },
      { h: 'Interior formatting', list: ['Title page, contents, author’s note and chapter openers', 'Page numbers: roman for front matter, then arabic', 'Layouts for Kindle eBooks, paperbacks and hardcovers on Amazon KDP', 'Bilingual layouts, with each text block placed beside its illustration'] },
      { h: 'Why editing and design from one person', p: ['Nothing gets lost in a handoff. Where a contents page or a copyright line needs a decision, I flag it as a question while I am formatting, not after the book is printed.'] },
      { h: 'Examples', p: ['The Book of Eno: a Kindle cover built to read at thumbnail size, with an interior of six page types. El Cocodrilo Kiko: an 80-page bilingual hardcover. Finding My Direction: a plain Word file turned into a designed interior with part pages and illustrated chapter openers.'] }
    ],
    quotes: [], projects: ['eno', 'kiko', 'fmd', 'skill', 'stop'],
    faqs: [
      ['Which platforms do you prepare files for?', 'Amazon KDP, for Kindle eBooks, paperbacks and hardcovers. Tell me the formats you need when you ask for a quote.'],
      ['Can you design from my own idea?', 'Yes. For The Book of Eno, I designed the Kindle cover with the author, starting from his concept: Eno, the old car and the church.']
    ]
  }
};
const SERVICE_ORDER = ['developmental-editing', 'line-and-copy-editing', 'proofreading', 'manuscript-assessment-and-beta-reading', 'book-cover-and-interior-design'];

const FAQS = [
  ['How does the free sample edit work?', 'Send the first 500 words of your manuscript by email or WhatsApp. I edit them with tracked changes and a comment explaining each change, then send them back. There is no cost and no obligation.'],
  ['Which type of editing do I need?', 'If the draft is new, or feels almost there, start with developmental editing. If the structure is settled, a line edit and copyedit polish the sentences. A proofread is the last check before you print or upload. Not sure? Send your sample and I will tell you honestly.'],
  ['Will you change my voice?', 'No. I tighten and clarify; I don’t rewrite you. The lines that carry your personality are left exactly as written, and I tell you which ones.'],
  ['What will I receive?', 'It depends on the service. A developmental edit comes as an editorial letter with chapter-by-chapter notes. A line edit comes as tracked changes with a reason beside each one. A copyedit gives you a clean manuscript with consistent style. An assessment or beta read comes as a written report with a ranked revision plan.'],
  ['What do you need to give me a quote?', 'Your word count, genre, the formats you need (Kindle, paperback or hardcover) and your launch date.'],
  ['How long will it take?', 'It depends on the length of your book and the type of editing. After I have seen your sample and your word count, I confirm a realistic timeline before we start.'],
  ['Where are your clients based?', 'I work with authors in the United States and Nigeria, remotely, by email and WhatsApp.'],
  ['What kinds of books do you edit?', 'Fiction, nonfiction and business books, memoir and personal growth, children’s books and academic writing. My projects above include a Christian novel, a bilingual picture book, a technology-and-society title and a personal memoir.'],
  ['Can you also design my cover and format my book?', 'Yes. Editing is my main service, but I also design covers (front, spine and back as one wrap) and format interiors for Kindle and print on Amazon KDP. Doing both means the promise on the cover matches what’s inside.'],
  ['Can I hire you through Upwork?', 'Yes. You can contact me directly using the form above, or hire me through my Upwork profile.', 'Yes. You can contact me directly using the form above, or hire me through <a href="' + SOCIAL.Upwork + '" target="_blank" rel="noopener">my Upwork profile</a>.']
];
const faqHtml = (list, cls) => `<div class="${cls}">\n` + list.map((f) => `      <details><summary>${esc(f[0])}</summary><div class="ans">${f[2] || esc(f[1])}</div></details>`).join('\n') + '\n    </div>';
const faqLd = (list) => ({ '@type': 'FAQPage', mainEntity: list.map((f) => ({ '@type': 'Question', name: f[0], acceptedAnswer: { '@type': 'Answer', text: f[1] } })) });

const AREAS = [{ '@type': 'Country', name: 'United States' }, { '@type': 'Country', name: 'Nigeria' }];
const BIZ_ID = SITE + '/#business', PERSON_ID = SITE + '/#person';
const url = (p) => SITE + '/' + p;

function head({ title, desc, file, image, ld, prefix }) {
  const canonical = file === 'index.html' ? SITE + '/' : url(file);
  const img = image ? url(image) : url('assets/og-image.jpg');
  return `<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>${esc(title)}</title>
<meta name="description" content="${esc(desc)}">
<meta name="robots" content="index, follow, max-image-preview:large">
<link rel="canonical" href="${canonical}">
<meta name="theme-color" content="#A947FC">
<meta property="og:type" content="website">
<meta property="og:site_name" content="Tijani Uthman, Book Editor">
<meta property="og:locale" content="en_US">
<meta property="og:title" content="${esc(title)}">
<meta property="og:description" content="${esc(desc)}">
<meta property="og:url" content="${canonical}">
<meta property="og:image" content="${img}">
<meta name="twitter:card" content="summary_large_image">
<meta name="twitter:title" content="${esc(title)}">
<meta name="twitter:description" content="${esc(desc)}">
<meta name="twitter:image" content="${img}">
<link rel="icon" href="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 64 64'%3E%3Crect width='64' height='64' rx='14' fill='%23A947FC'/%3E%3Cpath d='M18 20h28v7h-10.5v21h-7V27H18z' fill='%23fff'/%3E%3C/svg%3E">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Figtree:wght@400;500;600;700&family=Fraunces:ital,opsz,wght@0,9..144,400..700;1,9..144,400..600&display=swap" rel="stylesheet">
<link rel="stylesheet" href="${prefix}assets/site.css">
<script type="application/ld+json">
${JSON.stringify({ '@context': 'https://schema.org', '@graph': ld }, null, 2)}
</script>`;
}

function header(prefix, home) {
  const a = (id, label) => home ? `<a href="#${id}" data-section="${id}">${label}</a>` : `<a href="${prefix}index.html#${id}">${label}</a>`;
  return `<header class="site-header">
  <div class="wrap nav">
    <a class="brand" href="${home ? '#top' : prefix + 'index.html'}" aria-label="Tijani Uthman, book editor. ${home ? 'Back to top' : 'Home'}">
      <span class="brand-name">Tijani Uthman</span>
      <span class="brand-role">Book editor</span>
    </a>
    <button class="menu-btn" id="menuBtn" aria-expanded="false" aria-controls="navLinks">Menu</button>
    <nav class="nav-links" id="navLinks" aria-label="Main">
      ${a('services', 'Services')}
      ${a('process', 'How it works')}
      ${a('work', 'My work')}
      ${a('reviews', 'Reviews')}
      ${a('about', 'About')}
      ${a('faq', 'FAQ')}
      <a class="btn btn-primary" href="${home ? '' : prefix + 'index.html'}#free-sample">Free sample edit</a>
    </nav>
  </div>
</header>`;
}

function footer(prefix) {
  const svc = SERVICE_ORDER.map((s) => `<li><a href="${prefix}services/${s}.html">${SERVICES[s].nav}</a></li>`).join('\n          ');
  const prj = ORDER.map((k) => `<li><a href="${prefix}work/${SLUG[k]}.html">${esc(CASES[k].title)}</a></li>`).join('\n          ');
  return `<footer class="footer">
  <div class="wrap">
    <div class="foot-grid">
      <div class="foot-brand">
        <a class="brand" href="${prefix}index.html"><span class="brand-name">Tijani Uthman</span><span class="brand-role">Book editor</span></a>
        <p>Editing, proofreading and manuscript assessment for self-publishing authors in the United States and Nigeria.</p>
      </div>
      <div>
        <h2>Services</h2>
        <ul>
          ${svc}
        </ul>
      </div>
      <div>
        <h2>My work</h2>
        <ul>
          ${prj}
        </ul>
      </div>
      <div>
        <h2>Get in touch</h2>
        <ul>
          <li><a href="mailto:${EMAIL}">Email</a></li>
          <li><a href="${WA}" target="_blank" rel="noopener">WhatsApp</a></li>
          <li><a href="${SOCIAL.LinkedIn}" target="_blank" rel="noopener">LinkedIn</a></li>
          <li><a href="${SOCIAL.Upwork}" target="_blank" rel="noopener">Upwork</a></li>
        </ul>
      </div>
      <div>
        <h2>Follow</h2>
        <ul>
          <li><a href="${SOCIAL.Instagram}" target="_blank" rel="noopener">Instagram</a></li>
          <li><a href="${SOCIAL.Facebook}" target="_blank" rel="noopener">Facebook</a></li>
          <li><a href="${SOCIAL.TikTok}" target="_blank" rel="noopener">TikTok</a></li>
          <li><a href="${SOCIAL.Threads}" target="_blank" rel="noopener">Threads</a></li>
        </ul>
      </div>
    </div>
    <div class="legal">
      <p>Book covers and manuscript excerpts belong to their authors and appear here as examples of my work. Projects marked “Sample project” were made to show my process.</p>
      <p>© 2026 Tijani Uthman. All rights reserved.</p>
    </div>
  </div>
</footer>
<a class="float-wa" href="${WA}?text=Hi%20Tijani%2C%20I%27d%20like%20a%20free%20sample%20edit." target="_blank" rel="noopener" aria-label="Chat with Tijani on WhatsApp">
  <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M5 3h14a3 3 0 0 1 3 3v9a3 3 0 0 1-3 3h-7l-5 4v-4H5a3 3 0 0 1-3-3V6a3 3 0 0 1 3-3z"/></svg>
  <span>WhatsApp</span>
</a>`;
}

function workGrid(prefix) {
  const cards = ORDER.map((k) => {
    const c = CASES[k];
    const tags = c.tags.map((t) => `<li${t === 'Sample project' ? ' class="sample"' : ''}>${esc(t)}</li>`).join('');
    return `      <article class="work-card" data-cat="${c.cat.join(' ')}">
        <div class="work-img"><img class="${c.wide ? 'wide' : ''}" src="${prefix}${c.img}" alt="${esc(c.alt)}" loading="lazy"></div>
        <div class="work-body">
          <h3><a class="work-open" href="${prefix}work/${SLUG[k]}.html">${esc(c.title)}</a></h3>
          <p class="by">${c.sample ? 'Sample project' : 'by ' + esc(c.author)}</p>
          <ul class="tags">${tags}</ul>
          <p class="result">${esc(c.result)}</p>
          <span class="more" aria-hidden="true">Read the case study</span>
        </div>
      </article>`;
  }).join('\n');
  return `<div class="work-grid" id="workGrid">\n${cards}\n    </div>`;
}

function demoBlock(i) {
  const d = DEMOS[i];
  const views = [['before', 'Original'], ['after', 'My version']];
  if (d.tracked) views.push(['tracked', 'Tracked changes']);
  return `<div class="demo-panel" id="panel${i}" role="tabpanel" aria-labelledby="tab${i}"${i === 0 ? '' : ' hidden'}>
      <div class="demo-body">
        <div class="demo-text">
          <div class="view-switch" role="group" aria-label="View">${views.map((v) => `<button type="button" data-view="${v[0]}" aria-pressed="${v[0] === 'after'}">${v[1]}</button>`).join('')}</div>
          <div class="manuscript">${views.map((v) => `<div class="view" data-view="${v[0]}"${v[0] === 'after' ? '' : ' hidden'}>${d[v[0]]}</div>`).join('')}</div>
          <p class="words">${esc(d.where)}. ${esc(d.words)}</p>
        </div>
        <div class="comment">
          <div class="bubble"><b>Editor’s comment to the author</b><span>${esc(d.comment)}</span></div>
          <dl class="why"><dt>What I changed</dt><dd>${esc(d.changed)}</dd><dt>Why</dt><dd>${esc(d.why)}</dd><dt>Result for the author</dt><dd>${esc(d.result)}</dd></dl>
        </div>
      </div>
    </div>`;
}
function demoSection() {
  const tabs = DEMOS.map((d, i) => `<button class="demo-tab" type="button" role="tab" id="tab${i}" aria-controls="panel${i}" aria-selected="${i === 0}">${esc(d.tab)}</button>`).join('');
  return `<div class="demo" id="demo">
      <div class="demo-tabs" role="tablist" aria-label="Edit examples">${tabs}</div>
      ${DEMOS.map((d, i) => demoBlock(i)).join('\n      ')}
    </div>`;
}
function demoStatic(i) {
  const d = DEMOS[i];
  const part = (label, html) => `<h3>${label}</h3><div class="manuscript">${html}</div>`;
  return `<div class="demo-static">${part('Original', d.before)}${d.tracked ? part('Tracked changes', d.tracked) : ''}${part('My version', d.after)}<div class="bubble" style="margin-top:18px"><b>Editor’s comment to the author</b>${esc(d.comment)}</div></div>`;
}

function li(arr) { return '<ul class="list">' + arr.map((x) => `<li>${x}</li>`).join('') + '</ul>'; }
function caseBody(k, prefix) {
  const c = CASES[k];
  let h = '';
  h += `<div class="case-head${c.wide ? ' no-img' : ''}">${c.wide ? '' : `<img src="${prefix}${c.img}" alt="${esc(c.alt)}" width="200">`}<div><p class="case-sub">${esc(c.sub)}</p><dl class="facts">${Object.keys(c.facts).map((f) => `<dt>${esc(f)}</dt><dd>${esc(c.facts[f])}</dd>`).join('')}</dl></div></div>`;
  if (c.sample) h += `<p class="sample-flag"><b>Sample project.</b> I made this to show my process on a real-length manuscript. It is not a client project, and the manuscript excerpts belong to the author named in the project.</p>`;
  if (c.ba) h += `<div class="ba"><figure class="b"><figcaption>Before: the Word manuscript</figcaption><img src="${prefix}${c.ba[0]}" alt="Before: front matter and first chapter in default Word styles" loading="lazy"></figure><figure class="a"><figcaption>After: the book interior</figcaption><img src="${prefix}${c.ba[1]}" alt="After: part page with emblem and illustrated chapter opener" loading="lazy"></figure></div>`;
  if (c.table) h += `<table class="change-table"><caption class="visually-hidden">What changed, before and after</caption><thead><tr><th scope="col">Element</th><th scope="col">Before</th><th scope="col">After</th></tr></thead><tbody>${c.table.map((r) => `<tr><td>${esc(r[0])}</td><td>${esc(r[1])}</td><td>${esc(r[2])}</td></tr>`).join('')}</tbody></table>`;
  if (c.stats) h += `<div class="stats">${c.stats.map((s) => `<div class="stat"><b>${esc(s[0])}</b><span>${esc(s[1])}</span></div>`).join('')}</div>`;
  const cols = (c.cols || []).concat(c.extra || []);
  if (cols.length) h += `<div class="case-cols">${cols.map((x) => `<div><h2>${esc(x[0])}</h2>${li(x[1].map(esc))}</div>`).join('')}</div>`;
  if (c.detail) h += `<div class="detail"><small>${esc(c.detail[0])}</small>${esc(c.detail[1])}</div>`;
  if (c.quote) h += `<div class="case-quote"><p>${esc(c.quote[0])}</p><footer>${esc(c.quote[1])}</footer></div>`;
  if (PDF_FILES[k]) h += `<p class="pdf-row"><a class="btn btn-ghost" href="${prefix}assets/case-studies/${PDF_FILES[k]}" target="_blank" rel="noopener">Open the full case study (PDF)</a></p>`;
  return h;
}

function relatedProjects(keys, prefix) {
  return `<div class="related">${keys.map((k) => `<a href="${prefix}work/${SLUG[k]}.html"><img src="${prefix}${CASES[k].img}" alt="" loading="lazy">${esc(CASES[k].title)}<span>${CASES[k].sample ? 'Sample project' : 'by ' + esc(CASES[k].author)}</span></a>`).join('')}</div>`;
}
const sideCard = (prefix, extraHtml) => `<aside class="side">
        <div class="side-card">
          <h2>Get a free sample edit</h2>
          <p>Send your first 500 words. You get them back with tracked changes and a comment on every change. No obligation.</p>
          <a class="btn btn-primary" href="${prefix}index.html#free-sample">Request my sample edit</a>
        </div>
        ${extraHtml || ''}
        <div class="side-card">
          <h2>Contact me directly</h2>
          <ul><li><a href="mailto:${EMAIL}">Email me</a></li><li><a href="${WA}" target="_blank" rel="noopener">WhatsApp</a></li><li><a href="${SOCIAL.LinkedIn}" target="_blank" rel="noopener">LinkedIn</a></li></ul>
          <p style="margin:10px 0 0">Editing for authors in the United States and Nigeria.</p>
        </div>
      </aside>`;

const crumbs = (items, prefix) => `<nav class="crumbs" aria-label="Breadcrumb"><ol>${items.map((it, i) => i === items.length - 1 ? `<li aria-current="page">${esc(it[0])}</li>` : `<li><a href="${prefix}${it[1]}">${esc(it[0])}</a></li>`).join('')}</ol></nav>`;
const crumbLd = (items) => ({ '@type': 'BreadcrumbList', itemListElement: items.map((it, i) => { const o = { '@type': 'ListItem', position: i + 1, name: it[0] }; if (it[1] !== null) o.item = it[1] === 'index.html' ? SITE + '/' : url(it[1]); return o; }) });

function page({ prefix, title, desc, file, image, ld, bodyHtml }) {
  return `<!doctype html>
<html lang="en">
<head>
${head({ title, desc, file, image, ld, prefix })}
</head>
<body>
<a class="skip" href="#main">Skip to content</a>
${header(prefix, false)}
<main id="main">
${bodyHtml}
</main>
${footer(prefix)}
<script src="${prefix}assets/common.js" defer></script>
</body>
</html>
`;
}

const write = (rel, content) => { const f = path.join(OUT, rel); fs.mkdirSync(path.dirname(f), { recursive: true }); fs.writeFileSync(f, content); };
const pages = ['index.html'];

/* HOME */
{
  const prefix = '';
  const person = { '@type': 'Person', '@id': PERSON_ID, name: 'Tijani Uthman', jobTitle: 'Book editor', image: url('assets/media/tijani-uthman.webp'), email: EMAIL, sameAs: Object.values(SOCIAL).map((u) => u.split('?')[0]), knowsAbout: ['Developmental editing', 'Line editing', 'Copyediting', 'Proofreading', 'Manuscript assessment', 'Beta reading', 'Book cover design', 'Book interior formatting', 'Amazon KDP self-publishing'], worksFor: { '@id': BIZ_ID } };
  const biz = { '@type': 'ProfessionalService', '@id': BIZ_ID, name: 'Tijani Uthman, Book Editor', url: SITE + '/', image: url('assets/og-image.jpg'), description: 'Developmental editing, line and copy editing, proofreading and manuscript assessment for self-publishing authors in the United States and Nigeria.', email: EMAIL, areaServed: AREAS, founder: { '@id': PERSON_ID }, knowsLanguage: 'en', serviceType: SERVICE_ORDER.map((s) => SERVICES[s].serviceName), hasOfferCatalog: { '@type': 'OfferCatalog', name: 'Book editing services', itemListElement: SERVICE_ORDER.map((s) => ({ '@type': 'Offer', itemOffered: { '@type': 'Service', name: SERVICES[s].serviceName, url: url('services/' + s + '.html') } })) } };
  const website = { '@type': 'WebSite', '@id': SITE + '/#website', url: SITE + '/', name: 'Tijani Uthman, Book Editor', inLanguage: 'en' };
  const ld = [website, biz, person, faqLd(FAQS)];
  let t = fs.readFileSync(path.join(__dirname, 'home.template.html'), 'utf8');
  const fill = { HEAD: head({ title: 'Tijani Uthman | Book Editor for Authors in the US and Nigeria', desc: 'Book editor for self-publishing authors in the US and Nigeria. Developmental, line and copy editing, proofreading and manuscript assessment. Free 500-word sample edit.', file: 'index.html', ld, prefix }), HEADER: header(prefix, true), FOOTER: footer(prefix), WORKGRID: workGrid(prefix), DEMO: demoSection(), FAQ: faqHtml(FAQS, 'faq') };
  Object.keys(fill).forEach((k) => { if (!t.includes('{{' + k + '}}')) throw new Error('missing marker ' + k); t = t.replace('{{' + k + '}}', () => fill[k]); });
  write('index.html', t);
}

/* PROJECT PAGES */
ORDER.forEach((k) => {
  const prefix = '../', c = CASES[k], seo = CASE_SEO[k], file = `work/${SLUG[k]}.html`;
  pages.push(file);
  const items = [['Home', 'index.html'], ['My work', 'index.html#work'], [c.title, null]];
  const others = ORDER.filter((x) => x !== k).slice(0, 4);
  const used = seo.services.map((s) => `<li><a href="${prefix}services/${s}.html">${SERVICES[s].nav}</a></li>`).join('');
  const body = `<section class="page-hero">
  <div class="wrap">
    ${crumbs(items, prefix)}
    <h1 class="h-lg">${esc(c.title)}</h1>
    <p class="lead">${esc(c.result)}</p>
    <div class="cta-row"><a class="btn btn-primary" href="${prefix}index.html#free-sample">Get your free sample edit</a><a class="btn btn-ghost" href="${prefix}index.html#work">See all projects</a></div>
  </div>
</section>
<div class="wrap page-body case-page">
  <article class="prose">
    ${caseBody(k, prefix)}
    <h2>More projects</h2>
    ${relatedProjects(others, prefix)}
  </article>
  ${sideCard(prefix, `<div class="side-card"><h2>Services used</h2><ul>${used}</ul></div>`)}
</div>`;
  const ld = [crumbLd(items), { '@type': 'WebPage', '@id': url(file), url: url(file), name: seo.title, description: seo.desc, inLanguage: 'en', isPartOf: { '@id': SITE + '/#website' }, about: { '@id': BIZ_ID }, primaryImageOfPage: url(c.img) }];
  write(file, page({ prefix, title: `${seo.title} | Tijani Uthman`, desc: seo.desc, file, image: c.img, ld, bodyHtml: body }));
});

/* SERVICE PAGES */
SERVICE_ORDER.forEach((s) => {
  const prefix = '../', sv = SERVICES[s], file = `services/${s}.html`;
  pages.push(file);
  const items = [['Home', 'index.html'], ['Services', 'index.html#services'], [sv.nav, null]];
  const sections = sv.sections.map((sec) => `<h2>${esc(sec.h)}</h2>${(sec.p || []).map((p) => `<p>${esc(p)}</p>`).join('')}${sec.list ? li(sec.list.map(esc)) : ''}${sec.demo !== undefined ? demoStatic(sec.demo) : ''}`).join('\n    ');
  const quotes = sv.quotes.map((q) => `<figure class="quote feature"><blockquote>${esc(q[0])}</blockquote><footer><b>${esc(q[1])}</b></footer></figure>`).join('');
  const otherSvc = SERVICE_ORDER.filter((x) => x !== s).map((x) => `<li><a href="${x}.html">${SERVICES[x].nav}</a></li>`).join('');
  const body = `<section class="page-hero">
  <div class="wrap">
    ${crumbs(items, prefix)}
    <h1 class="h-lg">${esc(sv.h1)}</h1>
    <p class="lead">${esc(sv.lead)}</p>
    <div class="cta-row"><a class="btn btn-primary" href="${prefix}index.html#free-sample">Get your free sample edit</a><a class="btn btn-ghost" href="${prefix}index.html#work">See my work</a></div>
  </div>
</section>
<div class="wrap page-body">
  <article class="prose">
    ${sections}
    ${quotes ? '<h2>What authors say</h2>' + quotes : ''}
    <h2>Related projects</h2>
    ${relatedProjects(sv.projects, prefix)}
    <h2>Questions about this service</h2>
    ${faqHtml(sv.faqs, 'faq faq-mini')}
  </article>
  ${sideCard(prefix, `<div class="side-card"><h2>Other services</h2><ul>${otherSvc}</ul></div>`)}
</div>`;
  const ld = [crumbLd(items), { '@type': 'Service', '@id': url(file) + '#service', name: sv.serviceName, description: sv.desc, url: url(file), provider: { '@id': BIZ_ID }, areaServed: AREAS, serviceType: sv.serviceName }, faqLd(sv.faqs)];
  write(file, page({ prefix, title: `${sv.title} | Tijani Uthman`, desc: sv.desc, file, ld, bodyHtml: body }));
});

/* robots.txt and sitemap.xml */
const bots = ['GPTBot', 'OAI-SearchBot', 'ChatGPT-User', 'ClaudeBot', 'Claude-User', 'Claude-SearchBot', 'PerplexityBot', 'Google-Extended', 'Bingbot', 'Applebot'];
write('robots.txt', `# Everyone, including search engines and AI assistants, may read this site.
User-agent: *
Allow: /

${bots.map((b) => `User-agent: ${b}\nAllow: /`).join('\n\n')}

Sitemap: ${SITE}/sitemap.xml
`);
write('sitemap.xml', `<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
${pages.map((p) => `  <url><loc>${p === 'index.html' ? SITE + '/' : url(p)}</loc><lastmod>${TODAY}</lastmod><priority>${p === 'index.html' ? '1.0' : p.startsWith('services') ? '0.8' : '0.6'}</priority></url>`).join('\n')}
</urlset>
`);
console.log('Built', pages.length, 'pages for', SITE);
