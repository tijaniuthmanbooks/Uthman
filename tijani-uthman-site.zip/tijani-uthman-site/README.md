# Tijani Uthman, book editor: website

Static site. `build.js` generates every page into `dist/` from `data.json` and `home.template.html`. Images, CSS, JS, video and PDFs live in `assets/`.

## Deploy on Vercel (via GitHub)
1. Push this folder to a GitHub repository.
2. On vercel.com choose Add New > Project, import the repository. Framework Preset: Other. Vercel reads `vercel.json`, so leave the build settings alone.
3. Before deploying, open Settings > Environment Variables and add:
   - `CONTACT_EMAIL` = the email address that should appear on the site
   - `SITE_URL` = your final address, for example `https://yourdomain.com` (skip it to use the Vercel address)
4. Deploy. After adding a custom domain, update `SITE_URL` and redeploy.
5. Add the site to Google Search Console and Bing Webmaster Tools and submit `/sitemap.xml`.

## Change something
- Text of the home page: `home.template.html`
- Projects, case studies and edit examples: `data.json`
- Service pages, FAQ and SEO tags: `build.js`
- Styles: `assets/site.css`

Run locally (Node 18 or newer): `CONTACT_EMAIL=you@example.com SITE_URL=http://localhost:3000 node build.js`, then open `dist/index.html`.
